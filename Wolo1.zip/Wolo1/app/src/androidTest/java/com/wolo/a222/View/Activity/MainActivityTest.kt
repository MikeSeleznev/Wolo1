package com.wolo.a222.View.Activity

import android.support.test.runner.AndroidJUnit4
import org.junit.runner.RunWith


@RunWith(AndroidJUnit4::class)
class MainActivityTest {




}