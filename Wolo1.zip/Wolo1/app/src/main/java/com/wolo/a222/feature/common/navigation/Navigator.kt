package com.wolo.a222.feature.common.navigation

import android.app.Fragment
import android.content.Context
import android.support.v7.app.AppCompatActivity

interface Navigator {

    fun attachActivity(activity: AppCompatActivity)

    fun detachActivity(activity: AppCompatActivity)

    fun onStart()

    //fun onBackPressed(): Boolean

    fun onFinish(fragment: Fragment)

    fun startHomeLauncher(context: Context)
}