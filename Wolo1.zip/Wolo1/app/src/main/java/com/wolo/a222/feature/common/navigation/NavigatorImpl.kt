package com.wolo.a222.feature.common.navigation


import android.app.Fragment
import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import com.wolo.a222.R
import com.wolo.a222.feature.common.di.Scope.PerApplication
import javax.inject.Inject


@PerApplication
class NavigatorImpl
    @Inject constructor(): Navigator {

    private var activity: AppCompatActivity? = null

    private val fragmentManager
        get() = activity?.supportFragmentManager


    private val currentFragment
        get() = fragmentManager?.findFragmentById(R.id.content)


    override fun attachActivity(activity: AppCompatActivity) {
        this.activity = activity
    }

    override fun detachActivity(activity: AppCompatActivity) {
        if (this.activity == activity) {
            this.activity = null
        }
    }

  /*
    private fun replaceFragment(fragment: Fragment, addToBackStack: Boolean = true) = runOnUiThread {
        fragmentManager?.transaction {
            replace(R.id.content, fragment)
            if (addToBackStack) {
                addToBackStack(fragment::class.simpleName)
            }
        }
    }


    private fun clearBackStack() = runOnUiThread {
        fragmentManager?.popBackStackImmediate(null, POP_BACK_STACK_INCLUSIVE)
    }*/

    override fun onStart() {
        //replaceFragment(AuthFragment.newInstance(), false)
    }

    //override fun onBackPressed() = currentFragment is MarksFragment

    override fun onFinish(fragment: Fragment) {
        if (currentFragment == fragment) {
            fragmentManager?.popBackStack()
        }
    }

    override fun startHomeLauncher(context: Context) {
        val intent = Intent(Intent.ACTION_MAIN)
        intent.addCategory(Intent.CATEGORY_HOME)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        context.startActivity(intent)
    }
}