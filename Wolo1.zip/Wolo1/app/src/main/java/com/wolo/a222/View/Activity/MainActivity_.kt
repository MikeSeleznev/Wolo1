package com.wolo.a222.View.Activity

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.preference.PreferenceManager
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ListView
import android.widget.TextView
import com.google.gson.Gson
import com.wolo.a222.Cards
import com.wolo.a222.Game
import com.wolo.a222.Players
import com.wolo.a222.Presenter.MainActivityPresenter
import com.wolo.a222.R
import com.wolo.a222.View.Activity.GamezoneActivity
import com.wolo.a222.View.Activity.TopMenuActivity


import java.util.ArrayList


class MainActivity_ : AppCompatActivity() {

    internal lateinit var gamersListView: ListView
    internal lateinit var startGame: Button
    internal lateinit var addPlayer: Button
    internal lateinit var newUser: EditText
    internal lateinit var myListAdapter: MyListAdapter
    internal var players: Array<Players>? = null
    internal var sPref: SharedPreferences? = null
    internal lateinit var game: Game
    internal var cards: Array<Cards>? = null
    internal lateinit var topMenu: ImageButton
    internal var openFragment: Boolean? = null
    internal lateinit var closeMenuImageButton: ImageButton
    internal lateinit var presenter: MainActivityPresenter

    internal val gamersArray = ArrayList<String>()

    override fun onStart() {
        super.onStart()
        val gson = Gson()
        val json = PreferenceManager.getDefaultSharedPreferences(this).getString("game", "")
        game = gson.fromJson(json, Game::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.menu_main)
        init()
        presenter = MainActivityPresenter()
        openFragment = false

        gamersListView = findViewById<View>(R.id.gamers) as ListView
        myListAdapter = MyListAdapter(this, R.layout.list_row, gamersArray)
        gamersListView.adapter = myListAdapter
        newUser = findViewById<View>(R.id.newUser) as EditText
        startGame = findViewById<View>(R.id.startGame) as Button
        startGame.isEnabled = false
        topMenu = findViewById<View>(R.id.topmenu) as ImageButton
        closeMenuImageButton = findViewById<View>(R.id.closeMenuImageButton) as ImageButton
        closeMenuImageButton.visibility = View.INVISIBLE

        //Gson gson = new Gson();
        //String json = PreferenceManager.getDefaultSharedPreferences(this).getString("game", "");
        //game = gson.fromJson(json, Game.class);


        startGame.setOnClickListener {
            presenter.setData(this@MainActivity_, gamersArray)

            val intent = Intent(this@MainActivity_, GamezoneActivity::class.java)
            startActivity(intent)
        }

        addPlayer = findViewById<View>(R.id.add2) as Button
        addPlayer.setOnClickListener {
            val inputString = newUser.text.toString()
            if (inputString != "") {
                gamersArray.add(inputString)
                //game.addPlayer(inputString, gamersArray);
                myListAdapter.notifyDataSetChanged()
                newUser.setText("")
            }

            setEnterItemVisible()
        }

        topMenu.setOnClickListener {
            //Intent intent = new Intent(MainActivity.this,TopMenuActivity.class);
            // startActivity(intent);
            val fragmentManager = supportFragmentManager
            val fragment = fragmentManager.findFragmentById(R.id.fragment)
            if (openFragment == false) {
                val frag = TopMenuActivity()
                val ft = supportFragmentManager.beginTransaction()
                //ft.replace(R.id.fragment, frag);
                ft.add(R.id.fragment, frag)
                ft.addToBackStack(null)
                ft.commit()
                openFragment = true
                topMenu.visibility = View.INVISIBLE
                closeMenuImageButton.visibility = View.VISIBLE
            } else {
                val manager = supportFragmentManager
                val transaction = manager.beginTransaction()
                manager.backStackEntryCount
                transaction.remove(fragment!!)
                transaction.commit()
                openFragment = false
                //topMenu.setPressed(false);
                //closeMenuImageButton.setVisibility(View.VISIBLE);
            }
        }

        closeMenuImageButton.setOnClickListener {
            if (openFragment == true) {
                val fragmentManager = supportFragmentManager
                val fragment = fragmentManager.findFragmentById(R.id.fragment)
                val manager = supportFragmentManager
                val transaction = manager.beginTransaction()
                manager.backStackEntryCount
                transaction.remove(fragment!!)
                transaction.commit()
                openFragment = false
                topMenu.visibility = View.VISIBLE
                closeMenuImageButton.visibility = View.INVISIBLE
            }
        }

    }

    fun init(){
        presenter = MainActivityPresenter()
       // presenter.attachView(this)
    }


    inner class MyListAdapter(context: Context, private val layout: Int, objects: ArrayList<String>) : ArrayAdapter<String>(context, layout, objects) {


        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            var convertView = convertView
            var mainViewholder: ViewHolder? = null
            if (convertView == null) {
                val viewholder = ViewHolder()
                val inflater = LayoutInflater.from(context)
                convertView = inflater.inflate(layout, parent, false)
                viewholder.title = convertView!!.findViewById<View>(R.id.title) as TextView
                viewholder.button = convertView.findViewById<View>(R.id.DeleteUser) as ImageButton
                viewholder.buttonUser = convertView.findViewById(R.id.User)
                viewholder.buttonUser!!.text = game.getShortNameFromString(getItem(position))
                viewholder.title!!.text = getItem(position)
                viewholder.button!!.setOnClickListener {
                    gamersArray.removeAt(position)
                    myListAdapter.notifyDataSetChanged()
                    setEnterItemVisible()
                }

                convertView.tag = viewholder

            } else {
                mainViewholder = convertView.tag as ViewHolder
                mainViewholder.title!!.text = getItem(position)
            }
            return convertView

        }
    }

    private fun setEnterItemVisible() {
        var check = true
        var enab = true
        val checkSize = gamersArray.size
        if (checkSize == 8) {
            check = false
        }
        newUser.isEnabled = check
        addPlayer.isEnabled = check

        if (checkSize < 2) {
            enab = false
        }
        startGame.isEnabled = enab
    }

    inner class ViewHolder {

        var buttonUser: Button? = null
        internal var title: TextView? = null
        internal var button: ImageButton? = null
    }

    override fun onStop() {
        super.onStop()

    }

    override fun onDestroy() {
        super.onDestroy()
       // presenter.detachView()
    }
}
