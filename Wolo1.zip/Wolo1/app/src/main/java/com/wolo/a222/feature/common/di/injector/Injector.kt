package com.wolo.a222.feature.common.di.injector


import com.wolo.a222.feature.common.di.component.AppComponent
import ru.ireca.kitchen.feature.auth.di.component.AuthFeatureComponent
import ru.ireca.kitchen.feature.auth.di.component.AuthScreenComponent

interface Injector {

    fun getAppComponent(): AppComponent

    fun getAuthScreen(): AuthScreenComponent
    fun releaseAuthScreen()

    fun getAuthFeature(): AuthFeatureComponent
    fun releaseAuthFeature()
}