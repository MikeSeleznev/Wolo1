package com.wolo.a222.Presenter

import com.wolo.a222.feature.common.presenter.Presenter
import com.wolo.a222.feature.common.presenter.View

interface BasePresenter<V : View> : Presenter<V> {

}