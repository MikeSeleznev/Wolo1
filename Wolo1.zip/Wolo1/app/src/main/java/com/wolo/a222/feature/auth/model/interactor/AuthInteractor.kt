package com.wolo.a222.feature.auth.model.interactor



interface AuthInteractor {



}