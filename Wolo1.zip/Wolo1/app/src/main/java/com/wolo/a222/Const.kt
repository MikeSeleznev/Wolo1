package com.wolo.a222

object Const {
    const val USUAL = "ОБЫЧНАЯ"
    const val EXTREME = "ЭКСТРИМ"
    const val SPORT = "СПОРТ"
    const val EROTIC = "ЭРОТИКА"
    const val OHFUCK = "OHFUCK"
    const val ALLDECK = "Все колоды"
    const val base64EncodedPublicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA3vwp52URDdDppiTjaw6vVp80Sqepy5Tc8yZZeoC7D0f7d4AgzHviiXls8fX447GyBJIpuIOwVPQVCfAPYaqEfNa+m8ETRAYlG5pmHUlo7PtOGO3S5cGqrc1hl8Un36/Tjm2A5suBQ8i4VX46k6xKA5IjVZF8SHO2zQ7DDeWfvDX0uulsEQ5PfECRJOi81Om7e+hkLM+BproONa4QevwAP2cdv8Y7uWgjSL6WFvDYd3buEYuU27KtoOtLZp35ff6UaxP48oM1MS5CHvkTq1lNpJ6y0+QgfpUwPWZ9b8i54bGFnWa9kSJ9Q7uifI3O78uHTUAkS7JOKRFuZlCoD4OiPwIDAQAB"
    const val PACKS = "PACKS"
    const val CARDS = "CARDS"
    const val sportSKU = "000003"
    const val eroticSKU = "000005"
    const val ohfuckSKU = "000006"
    const val alldecksSKU = "000007"
    const val GAME = "game"
    const val FBCollection = "packs"
}
