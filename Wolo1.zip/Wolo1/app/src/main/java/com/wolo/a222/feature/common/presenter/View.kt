package com.wolo.a222.feature.common.presenter

interface View