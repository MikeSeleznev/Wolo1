package com.wolo.a222.feature.common.presenter



interface Presenter<V : View> {

    fun onFinish()

}