package com.wolo.a222.feature.common.view

import android.os.Bundle
import com.wolo.a222.R
import com.wolo.a222.feature.common.presenter.MainActivityPresenter
import javax.inject.Inject


class MainActivity : BaseActivity() {

    @Inject
    lateinit var presenter: MainActivityPresenter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        if (savedInstanceState == null){
            navigator.onStart()
        }
    }

}
