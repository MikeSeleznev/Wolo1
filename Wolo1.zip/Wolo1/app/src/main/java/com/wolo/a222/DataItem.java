package com.wolo.a222;

public class DataItem {
    int image = R.drawable.close;
    String gamerName;

    public DataItem(String gamerName){
        this.gamerName = gamerName;
    }
}
