package com.wolo.a222.feature.auth.view


import android.content.Context
import com.wolo.a222.R
import com.wolo.a222.feature.auth.presenter.AuthPresenter
import com.wolo.a222.feature.auth.presenter.AuthView
import com.wolo.a222.feature.common.view.PresenterFragment
import javax.inject.Inject

class AuthFragment : PresenterFragment<AuthPresenter>(), AuthView {

    companion object{
        fun newInstance() = AuthFragment()
    }

    @Inject
    override lateinit var presenter: AuthPresenter

    override val layoutResId: Int
        get() = R.layout.fragment_auth

    override fun onAttach(context: Context?) {
        injector.getAuthScreen().inject(this)
        super.onAttach(context)
    }


}