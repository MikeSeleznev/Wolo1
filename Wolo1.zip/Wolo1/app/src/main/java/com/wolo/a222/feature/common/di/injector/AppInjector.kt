package com.wolo.a222.feature.common.di.injector

import android.content.Context
import com.wolo.a222.feature.common.di.component.AppComponent
import com.wolo.a222.feature.common.di.component.DaggerAppComponent
import com.wolo.a222.feature.common.di.module.AppModule

class AppInjector(context: Context): Injector {

    private val appComponent: AppComponent = DaggerAppComponent.builder()
            .appModule(AppModule(context))
            .build()


    override fun getAppComponent() = appComponent

}