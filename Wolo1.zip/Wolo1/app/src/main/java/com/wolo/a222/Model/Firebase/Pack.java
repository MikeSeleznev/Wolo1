package com.wolo.a222.Model.Firebase;


public class Pack {

    public Packs packs;

    public Packs getPacks() {
        return packs;
    }

    public void setPacks(Packs packs) {
        this.packs = packs;
    }

}