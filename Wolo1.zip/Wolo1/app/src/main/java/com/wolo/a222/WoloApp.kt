package com.wolo.a222

import android.app.Application
import com.wolo.a222.feature.common.di.injector.AppInjector
import com.wolo.a222.feature.common.di.injector.Injector
import com.wolo.a222.feature.common.di.injector.InjectorProvider

class WoloApp: Application(), InjectorProvider {

    override lateinit var injector: Injector

    override fun onCreate() {
        super.onCreate()
        injector = AppInjector(this)
        injector.getAppComponent().inject(this)

    }
}

