package com.wolo.a222.Model.SKU

data class SkuDeck (val skuType: String, val name: String, val price: String, val imageName: String)