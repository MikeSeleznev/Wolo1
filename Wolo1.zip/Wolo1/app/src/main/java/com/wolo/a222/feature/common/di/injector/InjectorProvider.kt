package com.wolo.a222.feature.common.di.injector

interface InjectorProvider {
    val injector: Injector
}