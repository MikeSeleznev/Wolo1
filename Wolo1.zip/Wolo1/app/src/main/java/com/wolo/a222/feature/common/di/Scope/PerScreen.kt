package com.wolo.a222.feature.common.di.Scope

import javax.inject.Scope


@Scope @Retention(AnnotationRetention.RUNTIME)
annotation class PerScreen