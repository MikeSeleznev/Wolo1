package com.wolo.a222.Model.SKU

data class Sku (var Id: Int, var name: String, var price: String)